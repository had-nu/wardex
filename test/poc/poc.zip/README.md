# Wardex PoC — Risk-Based Release Gate Validation

End-to-end validation of the [wardex](https://github.com/had-nu/wardex) library
as a CI/CD release gate. Covers all four critical scenarios across both the CLI
and the Go SDK.

## Repository Structure

```
wardex-poc/
├── .github/
│   └── workflows/
│       └── wardex-gate.yml          # GitHub Actions pipeline
├── wardex/
│   ├── config/
│   │   └── wardex-config.yaml       # Risk appetite & gate policy
│   └── fixtures/
│       ├── controls.yaml            # Org ISO 27001 control inventory
│       ├── scenario-01-happy-path.yaml
│       ├── scenario-02-block-critical.yaml
│       ├── scenario-03-compensating-controls.yaml
│       └── scenario-04-risk-acceptance.yaml
├── sdk-poc/
│   ├── go.mod
│   └── main.go                      # Go SDK integration test
└── scripts/
    └── run-all-scenarios.sh         # Local runner (no CI needed)
```

## Scenarios

| # | Name | Input | Expected Decision |
|---|------|-------|------------------|
| 01 | Happy Path | CVSS 3.2, EPSS 0.02, not reachable | **ALLOW** |
| 02 | Critical Block | CVSS 9.8, EPSS 0.91, internet-facing, no controls | **BLOCK** |
| 03 | Compensating Controls | CVSS 8.1 + WAF 40% + auth 30% + segmentation 15% | **ALLOW** |
| 04 | Risk Acceptance | CVSS 9.1 → BLOCK → exception → re-evaluate → **ALLOW** | **ALLOW** (post-exception) |

## Prerequisites

- Go ≥ 1.22
- `WARDEX_HMAC_SECRET` environment variable (any strong random string)

## Quick Start (local)

```bash
# 1. Clone and enter the PoC
git clone <your-fork-url>
cd wardex-poc

# 2. Set the HMAC secret
export WARDEX_HMAC_SECRET="$(openssl rand -hex 32)"

# 3. Run all scenarios
chmod +x scripts/run-all-scenarios.sh
./scripts/run-all-scenarios.sh
```

## GitHub Actions

Push to `main` or `develop` to trigger the workflow automatically.

Add `WARDEX_HMAC_SECRET` as a repository secret under
**Settings → Secrets and variables → Actions**.

Each scenario runs as a parallel job. The final `release-decision` job
acts as a merge gate — it fails if any scenario produces an unexpected result.

## Risk Acceptance Flow (Scenario 04 Detail)

```
wardex gate → BLOCK (CVE-2025-0042, CVSS 9.1)
      │
      ▼
wardex accept request \
  --cve CVE-2025-0042 \
  --accepted-by sec-lead@company.com \
  --justification "WAF virtual patch active" \
  --expires 14d
      │
      ▼  (HMAC-SHA256 signed, append-only JSONL audit log)
      │
wardex gate → ALLOW  (exception honoured)
      │
wardex accept verify → integrity confirmed ✅
```

## Key Wardex Concepts Exercised

**Composite risk score** — Not raw CVSS. Wardex computes:

```
composite = CVSS_base × EPSS × criticality × reachability_factor
          × ∏(1 - control_effectiveness)
```

If `composite > risk_appetite` → BLOCK. This is why scenario 03 passes:
the controls reduce the effective score below 6.0 even though the raw CVSS is 8.1.

**Risk acceptance** — Formally signed exceptions with expiry, accepted-by,
and justification. Integrity is enforced via HMAC-SHA256 so tampering with
the audit log is detectable.
